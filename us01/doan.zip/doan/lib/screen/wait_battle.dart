import 'package:flutter/material.dart';
import 'package:flutter/src/widgets/container.dart';
import 'package:flutter/src/widgets/framework.dart';
import 'package:flutter_svg/svg.dart';
import 'package:gradient_borders/box_borders/gradient_box_border.dart';
import './battle.dart';
import '../components/appbar_custom.dart';
import '../components/bottom.dart';

class Waitbattle extends StatefulWidget {
  const Waitbattle({super.key});

  @override
  State<Waitbattle> createState() => _WaitbattleState();
}

class _WaitbattleState extends State<Waitbattle> {
  @override
  Widget build(BuildContext context) {
    return SafeArea(
        child: Scaffold(
      appBar: Header(Color_: Colors.transparent),
      bottomNavigationBar: bottom(),
      body: SafeArea(
        child: Container(
          decoration: const BoxDecoration(
            image: DecorationImage(
                image: AssetImage("images/back2.jfif"), fit: BoxFit.fill),
          ),
          child: Stack(children: [
            Padding(
              padding: const EdgeInsets.fromLTRB(30, 120, 0, 450),
              child: Row(
                children: [
                  Positioned(
                    top: 0,
                    child: GestureDetector(
                      onTap: () {
                        // ontap hình avatar
                      },
                      //chỗ bắt đầu
                      child: Container(
                        decoration: BoxDecoration(
                            gradient: LinearGradient(
                                begin: Alignment.topCenter,
                                end: Alignment.bottomCenter,
                                colors: [Color(0xffb92b27), Color(0xff1565c0)]),
                            border: Border.all(
                              width: 3,
                            ),
                            borderRadius: BorderRadius.circular(7)),
                        child: Container(
                          decoration: BoxDecoration(
                              border: GradientBoxBorder(
                                gradient: LinearGradient(colors: [
                                  Color(0xffee9ca7),
                                  Color(0xffffdde1)
                                ]),
                                width: 6,
                              ),
                              borderRadius: BorderRadius.circular(7)),
                          child: Container(
                            decoration: BoxDecoration(
                                border: Border.all(width: 3),
                                borderRadius: BorderRadius.circular(7)),
                            child: Image.network(
                              ("https://c4.wallpaperflare.com/wallpaper/733/860/1021/chill-out-clouds-landscape-mountains-wallpaper-preview.jpg"),
                              width: 100,
                            ),
                          ),
                        ),
                      ),
                    ),
                  ),
                  SizedBox(width: 20),
                  Text('Player 1')
                ],
              ),
            ),
            // const Padding(
            //   padding: EdgeInsets.fromLTRB(150, 200, 150, 150),
            //   child: Image(
            //     image: AssetImage('images/VS.png'),
            //     height: 200,
            //     width: 100,
            //   ),
            // ),
            Padding(
              padding: const EdgeInsets.fromLTRB(170, 350, 0, 0),
              child: Row(
                children: [
                  Text('Player 1'),
                  SizedBox(width: 20),
                  Positioned(
                    top: 0,
                    child: GestureDetector(
                      onTap: () {
                        // ontap hình avatar
                      },
                      //chỗ bắt đầu
                      child: Container(
                        decoration: BoxDecoration(
                            gradient: LinearGradient(
                                begin: Alignment.topCenter,
                                end: Alignment.bottomCenter,
                                colors: [Color(0xffb92b27), Color(0xff1565c0)]),
                            border: Border.all(
                              width: 3,
                            ),
                            borderRadius: BorderRadius.circular(7)),
                        child: Container(
                          decoration: BoxDecoration(
                              border: GradientBoxBorder(
                                gradient: LinearGradient(colors: [
                                  Color(0xffee9ca7),
                                  Color(0xffffdde1)
                                ]),
                                width: 6,
                              ),
                              borderRadius: BorderRadius.circular(7)),
                          child: Container(
                            decoration: BoxDecoration(
                                border: Border.all(width: 3),
                                borderRadius: BorderRadius.circular(7)),
                            child: Image.network(
                              ("https://c4.wallpaperflare.com/wallpaper/733/860/1021/chill-out-clouds-landscape-mountains-wallpaper-preview.jpg"),
                              width: 100,
                            ),
                          ),
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
            Padding(
                padding: const EdgeInsets.only(top: 550, left: 130),
                child: SizedBox(
                  height: 70,
                  width: 150,
                  child: OutlinedButton(
                    onPressed: () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: ((context) =>
                              const Battle()), // sửa lại đường dẫnnnnnn
                        ),
                      );
                    },
                    child: Text(
                      'Vào trận',
                      style: TextStyle(fontSize: 20, color: Colors.black),
                    ),
                    style: ButtonStyle(
                      shape: MaterialStateProperty.all(
                        RoundedRectangleBorder(
                            side: BorderSide(
                                color: Colors.black,
                                width: 1,
                                style: BorderStyle.solid),
                            borderRadius: BorderRadius.circular(50)),
                      ),
                    ),
                  ),
                )),
          ]),
        ),
      ),
    ));
  }
}
